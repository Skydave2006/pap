Historia do Geo Bogalho's 

No planeta cubo existe uma grande guerra entre cubos.
Existe vários tipos de quadrados, mas aos poucos alguns tipos estão-se a extinguir, os que não morrem em guerra são tornados escravos. O jogador jogara com um quadrado azul um tipo de quadrados que não avançou na tecnologia, tornando-se a maioria escravos, são muito pacíficos.

Enciclopédia do planeta Cubo:

Cubos Azuis:

Pacíficos, recusaram-se a lutar contra os cubos amarelos, sendo capturados e escravizados pelos mesmos. 	Não avançaram tecnologicamente, mas tem um alto potencial de telecinesia. Eram liderados pelo Sábio.  

Cubos Amarelos:

Prodígios na tecnologia, foram os que mais avançaram tecnologicamente mesmo tendo uma baixa maestria em 	telecinesia, possuem as armas de guerra mais avançadas. Odeiam cubos Vermelhos. São Democráticos.

Cubos Vermelho:

Não acreditam na nova tecnologia, são mestres na telecinesia, adoram chacina acreditam que só pode haver 	um tipo de cubos existente, conhecidos por extinguir vários tipos de cubos. Liderados pelo Líder.

Cubos Verdes:

Uma pequena tribo, poucos relatos sobre esse tipo de cubos, são muito discretos.

Cubos Laranja:

Extinto.

Cubo Rosa:

Extinto.

Cubo Castanho:

Mito.

Cubo Preto:

Apenas uma antiga Lenda.


Jogador:

Tipo de Cubo: Azul
Nome: Askj(Arthur)
Estado: Escravo numa aldeia de cubos Amarelos

Começo: 

Mais um dia para Askj, até que a vila é invadida por cubos Vermelhos e levam Askj para lutar na Arena. Tutorial. Após Askj ganhar, começa a procurar uma forma de sair da Arena, ela encontra uma conduta que leva até onde eram despejados os cubos mortos na Arena, apos fugir e ser considerado foragido pelos cubos Amarelos e Vermelhos, Askj vê um novo rumo na sua vida, procurar a paz.
Então Askj vai começar por procurar os Cubos Verdes.
